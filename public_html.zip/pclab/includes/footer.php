    </div>
    <footer class="bg-dark text-white mt-5">
        <div class="container py-4">
            <div class="row">
                <div class="col-md-6">
                    <h5>UNILAB</h5>
                    <p>© 2024 Tüm hakları saklıdır.</p>
                </div>
                <div class="col-md-6 text-end">
                    <ul class="list-inline">
                        <li class="list-inline-item"><a href="<?= SITE_URL ?>/about.php">Hakkımızda</a></li>
                        <li class="list-inline-item"><a href="<?= SITE_URL ?>/news.php">Haberler</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html> 