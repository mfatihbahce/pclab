<div class="sidebar bg-dark">
    <div class="sidebar-header">
        <h3 class="text-white">Admin Panel</h3>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="<?= SITE_URL ?>/admin/dashboard">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= SITE_URL ?>/admin/about-manage">
                <i class="bi bi-file-text"></i> Hakkımızda
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= SITE_URL ?>/admin/gallery-manage">
                <i class="bi bi-images"></i> Galeri
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= SITE_URL ?>/admin/projects-manage">
                <i class="bi bi-briefcase"></i> Çalışmalar
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="news-manage">
                <i class="bi bi-newspaper"></i> Haber Yönetimi
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?= SITE_URL ?>/admin/contact-manage">
                <i class="bi bi-envelope"></i> İletişim Mesajları
            </a>
        </li>

            <li class="nav-item">
        <a class="nav-link" href="<?= SITE_URL ?>/admin/unit-manage">
            <i class="bi bi-building"></i> Birimler
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= SITE_URL ?>/admin/training-manage">
            <i class="bi bi-mortarboard"></i> Eğitimler
        </a>
    </li>
        <li class="nav-item">
        <a class="nav-link" href="<?= SITE_URL ?>/admin/student-list">
            <i class="bi bi-list"></i> Öğrenci Listesi
        </a>
    </li>
    <!-- Eğitim Yönetimi kategorisine ekle -->
<li class="nav-item">
    <a class="nav-link <?= str_contains($current_page, 'add-student-registration.php') ? 'active' : '' ?>" 
       href="<?= SITE_URL ?>/admin/add-student-registration">
        <i class="bi bi-person-plus me-2"></i>
        <span>Manuel Başvuru</span>
    </a>
</li>
    </ul>
</div>