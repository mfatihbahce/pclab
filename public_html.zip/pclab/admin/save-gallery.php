<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
checkAdmin();

$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Yüklenen dosyaları kontrol et
    if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
        $uploaded_files = $_FILES['images'];
        $success_count = 0;
        $error_count = 0;
        
        // Yükleme klasörünü kontrol et ve oluştur
        $upload_dir = '../uploads/gallery/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Her bir dosya için işlem yap
        for ($i = 0; $i < count($uploaded_files['name']); $i++) {
            $file = [
                'name' => $uploaded_files['name'][$i],
                'type' => $uploaded_files['type'][$i],
                'tmp_name' => $uploaded_files['tmp_name'][$i],
                'error' => $uploaded_files['error'][$i],
                'size' => $uploaded_files['size'][$i]
            ];

            // Dosya uzantısını kontrol et
            $allowed_types = ['jpg', 'jpeg', 'png', 'webp'];
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if (!in_array($file_ext, $allowed_types)) {
                setError("Desteklenmeyen dosya formatı: {$file['name']}");
                $error_count++;
                continue;
            }

            // Dosya boyutunu kontrol et (5MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                setError("Dosya boyutu çok büyük: {$file['name']}");
                $error_count++;
                continue;
            }

            // Benzersiz dosya adı oluştur
            $new_filename = uniqid('gallery_') . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;

            // Dosyayı yükle
            if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                // Görsel boyutlarını al
                list($width, $height) = getimagesize($upload_path);

                // Veritabanına kaydet
                $insert = $db->query(
                    "INSERT INTO gallery (image_path, title, width, height, created_at) VALUES (?, ?, ?, ?, NOW())",
                    [$new_filename, clean($_POST['title'][$i] ?? ''), $width, $height]
                );

                if ($insert) {
                    $success_count++;
                } else {
                    unlink($upload_path); // Dosyayı sil
                    $error_count++;
                }
            } else {
                setError("Dosya yüklenemedi: {$file['name']}");
                $error_count++;
            }
        }

        // Sonuç mesajlarını göster
        if ($success_count > 0) {
            setSuccess("$success_count adet görsel başarıyla yüklendi.");
        }
        if ($error_count > 0) {
            setError("$error_count adet görsel yüklenemedi.");
        }
    } else {
        setError("Lütfen görsel seçin.");
    }
    
    // Galeri sayfasına yönlendir
    header("Location: gallery-manage.php");
    exit;
}

$page_title = 'Galeri Yükleme';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Galeri Yükleme</h2>
        <a href="gallery-manage.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Geri Dön
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data" id="galleryForm">
                <div class="mb-3">
                    <label for="images" class="form-label">Görseller</label>
                    <input type="file" class="form-control" id="images" name="images[]" 
                           accept="image/jpeg,image/png,image/webp" multiple required>
                    <div class="form-text">
                        Desteklenen formatlar: JPG, PNG, WEBP<br>
                        Maksimum dosya boyutu: 5MB
                    </div>
                </div>

                <div id="imagePreview" class="row g-3 mb-3"></div>

                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-cloud-upload"></i> Yükle
                </button>
            </form>
        </div>
    </div>
</div>

<style>
.preview-item {
    position: relative;
}

.preview-image {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
}

.preview-title {
    margin-top: 0.5rem;
}

.remove-preview {
    position: absolute;
    top: 10px;
    right: 25px;
    background: rgba(255,255,255,0.9);
    border: none;
    border-radius: 50%;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.remove-preview:hover {
    background: #dc3545;
    color: white;
}
</style>

<script>
document.getElementById('images').addEventListener('change', function(e) {
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = '';
    
    Array.from(e.target.files).forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const col = document.createElement('div');
            col.className = 'col-md-3 preview-item';
            
            col.innerHTML = `
                <img src="${e.target.result}" class="preview-image" alt="Preview">
                <input type="text" class="form-control preview-title" 
                       name="title[]" placeholder="Görsel başlığı">
                <button type="button" class="remove-preview" 
                        onclick="this.parentElement.remove()">
                    <i class="bi bi-x"></i>
                </button>
            `;
            
            preview.appendChild(col);
        }
        reader.readAsDataURL(file);
    });
});
</script>

<?php include 'includes/footer.php'; ?>