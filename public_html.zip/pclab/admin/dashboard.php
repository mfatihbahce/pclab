<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';
checkAdmin();

$db = Database::getInstance();

// İstatistikleri al
$stats = [
    'users' => $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'],
    'members' => $db->query("SELECT COUNT(*) as count FROM members")->fetch()['count'],
    'gallery' => $db->query("SELECT COUNT(*) as count FROM gallery")->fetch()['count'],
    'projects' => $db->query("SELECT COUNT(*) as count FROM projects")->fetch()['count'],
    'messages' => $db->query("SELECT COUNT(*) as count FROM contact_messages")->fetch()['count']
];

// Toplam peşinat miktarını al
$total_deposit = $db->query("SELECT SUM(deposit_amount) as total FROM members")->fetch()['total'];


// Son mesajları al
$latest_messages = $db->query("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 3")->fetchAll();

// Son üyeleri al
$latest_members = $db->query("SELECT * FROM members ORDER BY created_at DESC LIMIT 3")->fetchAll();

// Haftalık peşinat grafiği için veri
$lastWeeks = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m-%d') as day,
           SUM(deposit_amount) as total
    FROM members
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')
    ORDER BY day ASC
")->fetchAll();

// Son 3 aylık peşinat grafiği için veri
$last3Months = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month,
           SUM(deposit_amount) as total
    FROM members
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 3 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month ASC
")->fetchAll();

// Son 12 aylık peşinat grafiği için veri
$last12Months = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month,
           SUM(deposit_amount) as total
    FROM members
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY month ASC
")->fetchAll();

include 'includes/header.php';
?>

<h2 class="mb-4">Dashboard</h2>

<div class="row g-4 mb-4">
    <div class="col">
        <div class="card bg-primary text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title mb-3">Toplam Kullanıcı</h6>
                        <h2 class="mb-0"><?= $stats['users'] ?></h2>
                    </div>
                    <div class="icon-box">
                        <i class="bi bi-people-fill"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col">
        <div class="card bg-success text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title mb-3">Toplam Üye</h6>
                        <h2 class="mb-0"><?= $stats['members'] ?></h2>
                    </div>
                    <div class="icon-box">
                        <i class="bi bi-person-vcard-fill"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col">
        <div class="card bg-info text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title mb-3">Galeri Öğeleri</h6>
                        <h2 class="mb-0"><?= $stats['gallery'] ?></h2>
                    </div>
                    <div class="icon-box">
                        <i class="bi bi-images"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col">
        <div class="card bg-warning text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title mb-3">Toplam Proje</h6>
                        <h2 class="mb-0"><?= $stats['projects'] ?></h2>
                    </div>
                    <div class="icon-box">
                        <i class="bi bi-building"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col">
        <div class="card bg-danger text-white h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title mb-3">Toplam Peşinat</h6>
                        <h2 class="mb-0">₺<?= number_format($total_deposit, 2, ',', '.') ?></h2>
                    </div>
                    <div class="icon-box">
                        <i class="bi bi-cash-stack"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Son Mesajlar</h5>
            </div>
            <div class="card-body">
                <?php if ($latest_messages): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>İsim</th>
                                    <th>Konu</th>
                                    <th>Tarih</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($latest_messages as $message): ?>
                                    <tr>
                                        <td><?= clean($message['name']) ?></td>
                                        <td><?= clean($message['subject']) ?></td>
                                        <td><?= date('d.m.Y', strtotime($message['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="mb-0">Henüz mesaj bulunmuyor.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Son Üyeler</h5>
            </div>
            <div class="card-body">
                <?php if ($latest_members): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Üye No</th>
                                    <th>Ad Soyad</th>
                                    <th>Tarih</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($latest_members as $member): ?>
                                    <tr>
                                        <td><?= clean($member['member_no']) ?></td>
                                        <td><?= clean($member['first_name'] . ' ' . $member['last_name']) ?></td>
                                        <td><?= date('d.m.Y', strtotime($member['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="mb-0">Henüz üye bulunmuyor.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
        <!-- Grafikler -->
    <div class="row g-4 mb-4">
        <!-- Haftalık Peşinat Grafiği -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title">Haftalık Peşinat</h5>
                    <canvas id="lastWeekChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Son 3 Aylık Peşinat Grafiği -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title">Son 3 Aylık Peşinat</h5>
                    <canvas id="last3MonthsChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Son 12 Aylık Peşinat Grafiği -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title">Son 12 Aylık Peşinat</h5>
                    <canvas id="last12MonthsChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    
</div>

<!-- Chart.js Kütüphanesi -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    .card {
        transition: transform 0.2s;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .bi {
        opacity: 0.8;
    }

    /* Grafik kartları için sabit yükseklik */
    .card canvas {
        height: 300px !important; /* Sabit yükseklik */
        width: 100% !important;  /* Yatayda tam genişlik */
    }

    /* Responsive düzenlemeler */
    @media (max-width: 768px) {
        .col-md-4 {
            flex: 0 0 100%;
            margin-bottom: 1rem;
        }
    }
</style>

<script>
// Haftalık Grafik
new Chart(document.getElementById('lastWeekChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_map(function($item) {
            $gunler = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
            return $gunler[date('w', strtotime($item['day']))];
        }, $lastWeeks)) ?>,
        datasets: [{
            label: 'Günlük Peşinat (₺)',
            data: <?= json_encode(array_column($lastWeeks, 'total')) ?>,
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Son 7 Günün Peşinat Dağılımı'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString('tr-TR', {
                            style: 'currency',
                            currency: 'TRY'
                        });
                    }
                }
            }
        }
    }
});

// 3 Aylık Grafik
new Chart(document.getElementById('last3MonthsChart'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_map(function($item) {
            $aylar = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 
                     'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
            $ay = date('n', strtotime($item['month'])) - 1;
            return $aylar[$ay];
        }, $last3Months)) ?>,
        datasets: [{
            label: 'Aylık Peşinat (₺)',
            data: <?= json_encode(array_column($last3Months, 'total')) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Son 3 Ayın Peşinat Dağılımı'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString('tr-TR', {
                            style: 'currency',
                            currency: 'TRY'
                        });
                    }
                }
            }
        }
    }
});

// 12 Aylık Grafik
new Chart(document.getElementById('last12MonthsChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode(array_map(function($item) {
            return date('m', strtotime($item['month']));
        }, $last12Months)) ?>,
        datasets: [{
            label: 'Aylık Peşinat (₺)',
            data: <?= json_encode(array_column($last12Months, 'total')) ?>,
            fill: true,
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Son 12 Ayın Peşinat Dağılımı'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString('tr-TR', {
                            style: 'currency',
                            currency: 'TRY'
                        });
                    }
                }
            }
        }
    }
});
</script>
<style>
.card {
    transition: transform 0.2s, box-shadow 0.2s;
    border: none;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.icon-box {
    font-size: 2.5rem;
    opacity: 0.8;
    margin-left: 1rem;
}

.card-body {
    padding: 1.5rem;
}

.card-title {
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Responsive düzenlemeler */
@media (max-width: 1200px) {
    .col {
        flex: 0 0 calc(50% - 1rem);
        margin-bottom: 1rem;
    }
}

@media (max-width: 768px) {
    .col {
        flex: 0 0 100%;
    }
    
    .icon-box {
        font-size: 2rem;
    }
}
</style>
<?php include 'includes/footer.php'; ?>