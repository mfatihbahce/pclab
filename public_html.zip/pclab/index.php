<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';


$db = Database::getInstance();
// Son 4 haberi getir
$news = $db->query("SELECT * FROM news ORDER BY created_at DESC LIMIT 4")->fetchAll();

// Son 4 projeyi getir
$projects = $db->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 4")->fetchAll();

// Galeri görsellerini getir
$gallery_images = $db->query("SELECT * FROM gallery ORDER BY created_at DESC LIMIT 6")->fetchAll();

$page_title = 'Ana Sayfa';
include 'includes/header.php';
?>


<!-- Hero Section -->
<div class="hero-section mb-5">
    <div class="container h-100">
        <div class="row align-items-center justify-content-between min-vh-75">
            <div class="col-md-6 pe-md-5">
                <h2 class="display-4 fw-bold mb-4">🤖 Hayallerini Kodla!</h2>
                <p class="lead mb-4">Robotik kodlama ve yazılım eğitimlerine başvurunu yap, teknoloji dünyasına adım at! Hemen şimdi yerini ayırt!</p>
                <div class="text-center text-md-start">
                    <a href="contact.php" class="btn btn-primary btn-lg px-4">İletişime Geçin</a>
                </div>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <img src="https://education.vex.com/stemlabs/sites/default/files/inline-images/Overview%20Compeition%20Base%202.0%20%2B%20Claw%20Hero%20Robot_0.png" 
                     alt="Hero Image" 
                     class="hero-image img-fluid">
            </div>
        </div>
    </div>
</div>

<!-- Eğitimler Section -->
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Aktif Eğitimler</h2>
        <a href="trainings.php" class="btn btn-outline-primary">Tüm Eğitimleri Gör</a>
    </div>
    
    <div class="row g-4">
        <?php
        // Aktif eğitimleri getir (son 4 eğitim)
        $trainings = $db->query(
            "SELECT t.*, u.name as unit_name, u.address,
                    (SELECT COUNT(*) FROM training_registrations WHERE training_id = t.id) as registered
             FROM trainings t 
             JOIN units u ON t.unit_id = u.id 
             WHERE t.is_active = 1 AND t.end_date >= CURDATE()
             ORDER BY t.start_date ASC
             LIMIT 4"
        )->fetchAll();

        if ($trainings):
            foreach ($trainings as $training): 
        ?>
            <div class="col-md-3">
                <div class="card h-100 training-card">
                    <!-- Eğitim İkonu -->
                    <div class="card-img-top bg-light text-center py-4">
                        <i class="bi bi-mortarboard-fill text-primary" style="font-size: 3rem;"></i>
                    </div>
                    
                    <div class="card-body">
                        <!-- Eğitim Başlığı -->
                        <h5 class="card-title"><?= htmlspecialchars($training['title']) ?></h5>
                        
                        <!-- Eğitim Detayları -->
                        <ul class="list-unstyled mb-3">
                            <li class="mb-2">
                                <i class="bi bi-building me-2 text-primary"></i>
                                <?= htmlspecialchars($training['unit_name']) ?>
                            </li>
                            <li class="mb-2">
                                <i class="bi bi-calendar3 me-2 text-primary"></i>
                                <?= date('d.m.Y', strtotime($training['start_date'])) ?>
                            </li>
                            <li>
                                <i class="bi bi-people me-2 text-primary"></i>
                                Kontenjan: <?= $training['registered'] ?>/<?= $training['capacity'] ?>
                            </li>
                        </ul>
                    </div>

                    <div class="card-footer bg-white border-top-0">
                        <?php if ($training['registered'] < $training['capacity']): ?>
                            <a href="training-register.php?id=<?= $training['id'] ?>" 
                               class="btn btn-primary w-100">
                                <i class="bi bi-person-plus me-1"></i>Başvur
                            </a>
                        <?php else: ?>
                            <button class="btn btn-secondary w-100" disabled>
                                <i class="bi bi-x-circle me-1"></i>Kontenjan Dolu
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php 
            endforeach;
        else:
        ?>
            <div class="col-12">
                <div class="alert alert-info text-center">
                    <i class="bi bi-info-circle me-2"></i>
                    Şu anda açık eğitim bulunmamaktadır.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Haberler Section -->
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Son Haberler</h2>
        <a href="news.php" class="btn btn-outline-primary">Tüm Haberleri Gör</a>
    </div>
    
    <div class="row g-4">
        <?php foreach ($news as $item): ?>
            <div class="col-md-3">
                <div class="card h-100 news-card">
                    <?php if ($item['image_path']): ?>
                        <img src="<?= SITE_URL ?>/uploads/news/<?= $item['image_path'] ?>" 
                             class="card-img-top" alt="<?= clean($item['title']) ?>"
                             style="height: 200px; object-fit: cover;">
                    <?php endif; ?>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?= clean($item['title']) ?></h5>
                        <p class="card-text flex-grow-1">
                            <?= mb_substr(strip_tags($item['content']), 0, 100) ?>...
                        </p>
                        <div class="mt-auto">
                            <small class="text-muted d-block mb-2">
                                <?= date('d.m.Y', strtotime($item['created_at'])) ?>
                            </small>
                            <button type="button" class="btn btn-primary w-100" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#newsModal<?= $item['id'] ?>">
                                Devamını Oku
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Haber Detay Modal -->
            <div class="modal fade" id="newsModal<?= $item['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= clean($item['title']) ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <?php if ($item['image_path']): ?>
                                <img src="<?= SITE_URL ?>/uploads/news/<?= $item['image_path'] ?>" 
                                     class="img-fluid mb-3" alt="<?= clean($item['title']) ?>">
                            <?php endif; ?>
                            <div class="content">
                                <?= $item['content'] ?>
                            </div>
                            <hr>
                            <small class="text-muted">
                                Yayınlanma Tarihi: <?= date('d.m.Y H:i', strtotime($item['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Projeler Section -->
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Duyurularımız</h2>
        <a href="projects.php" class="btn btn-outline-primary">Tüm Duyuruları Gör</a>
    </div>
    
    <div class="row g-4">
        <?php foreach ($projects as $project): ?>
            <div class="col-md-3">
                <div class="card h-100 project-card">
                    <img src="<?= SITE_URL ?>/uploads/projects/<?= $project['image_path'] ?>" 
                         class="card-img-top" alt="<?= clean($project['title']) ?>"
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?= clean($project['title']) ?></h5>
                        <p class="card-text flex-grow-1">
                            <?= mb_substr(clean($project['description']), 0, 100) ?>...
                        </p>
                        <a href="projects.php" class="btn btn-primary mt-auto">Detayları Gör</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>




<!-- Galeri Section -->
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Galeri</h2>
        <a href="gallery.php" class="btn btn-outline-primary">Tüm Görselleri Gör</a>
    </div>
    
    <div class="row g-4">
        <?php 
        // Son 6 galeri öğesini getir
        $gallery = $db->query("SELECT * FROM gallery ORDER BY created_at DESC LIMIT 6")->fetchAll();
        foreach ($gallery as $item): 
        ?>
            <div class="col-md-4 col-lg-2">
                <div class="card h-100 gallery-card">
                    <div class="gallery-image-container">
                        <img src="<?= SITE_URL ?>/uploads/gallery/<?= $item['image_path'] ?>" 
                             class="card-img-top gallery-image" 
                             alt="<?= clean($item['title']) ?>"
                             data-bs-toggle="modal" 
                             data-bs-target="#galleryModal<?= $item['id'] ?>">
                        
                        <!-- Hover Overlay -->
                        <div class="gallery-overlay">
                            <button type="button" class="btn btn-light btn-sm" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#galleryModal<?= $item['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-2">
                        <h6 class="card-title text-truncate mb-0"><?= clean($item['title']) ?></h6>
                    </div>
                </div>
            </div>

            <!-- Görsel Modal -->
            <div class="modal fade" id="galleryModal<?= $item['id'] ?>" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header border-0">
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center p-0">
                            <img src="<?= SITE_URL ?>/uploads/gallery/<?= $item['image_path'] ?>" 
                                 class="img-fluid" alt="<?= clean($item['title']) ?>">
                        </div>
                        <div class="modal-footer">
                            <div class="w-100">
                                <h5 class="modal-title mb-2"><?= clean($item['title']) ?></h5>
                                <?php if (!empty($item['description'])): ?>
                                    <p class="text-muted mb-2"><?= nl2br(clean($item['description'])) ?></p>
                                <?php endif; ?>
                                <small class="text-muted">
                                    <?= date('d.m.Y', strtotime($item['created_at'])) ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- İletişim Bölümü -->
<section class="contact-section bg-light py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="section-title">İletişime Geçin</h2>
                <p>Sorularınız için bize ulaşabilirsiniz.</p>
                <ul class="list-unstyled">
                    <li><i class="bi bi-geo-alt"></i> Adres: İstanbul, Türkiye</li>
                    <li><i class="bi bi-telephone"></i> Telefon: +90 123 456 7890</li>
                    <li><i class="bi bi-envelope"></i> E-posta: info@example.com</li>
                </ul>
            </div>
            <div class="col-md-6">
                <a href="contact.php" class="btn btn-lg btn-primary">Mesaj Gönderin</a>
            </div>
        </div>
    </div>
</section>

<!-- Galeri Stilleri -->
<style>
.gallery-card, .project-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    cursor: pointer;
    border: none;
}

.gallery-card:hover, .project-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.gallery-image-container {
    position: relative;
    height: 150px;
    overflow: hidden;
}

.gallery-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.gallery-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.gallery-image-container:hover .gallery-overlay {
    opacity: 1;
}

.gallery-image-container:hover .gallery-image {
    transform: scale(1.1);
}

.card-title {
    font-size: 0.9rem;
    color: #333;
}

/* Modal Stilleri */
.modal-content {
    border: none;
    border-radius: 10px;
    overflow: hidden;
}

.modal-header .btn-close {
    position: absolute;
    right: 1rem;
    top: 1rem;
    z-index: 1;
    background-color: white;
    border-radius: 50%;
    padding: 0.5rem;
}

.modal-body img {
    max-height: 80vh;
    object-fit: contain;
}

/* Hero section stilleri */
.hero-section {
    background-color: #fff;
    padding: 2rem 0;
    margin: 2rem auto;
    overflow: hidden;
    max-width: 1400px;
}

.hero-container {
    background-color: #f8f9fa;
    border-radius: 300px;
    padding: 3rem 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.05);
    margin: 0 1rem;
}

.hero-section h1 {
    font-weight: 700;
    color: #2d3436;
    line-height: 1.2;
}

.hero-section .lead {
    color: #636e72;
    font-size: 1.25rem;
    line-height: 1.6;
}

.hero-section .btn-lg {
    padding: 1rem 2rem;
    font-weight: 500;
    border-radius: 15px;
    transition: transform 0.3s ease;
}

.hero-section .btn-lg:hover {
    transform: translateY(-3px);
}

.hero-image {
    max-width: 90%;
    height: auto;
    transform: scale(1.1);
}

/* Responsive düzenlemeler */
@media (max-width: 991px) {
    .hero-container {
        padding: 2rem 1.5rem;
    }
    
    .hero-section h1 {
        font-size: 2.5rem;
    }
    
    .hero-section .lead {
        font-size: 1.1rem;
    }
}

@media (max-width: 768px) {
    .hero-container {
        padding: 2rem 1rem;
        margin: 0 0.5rem;
        border-radius: 20px;
    }
    
    .hero-section {
        text-align: center;
        padding: 1rem 0;
    }
    
    .hero-section .row {
        flex-direction: column-reverse;
    }
    
    .col-md-6 {
        padding: 1rem 15px;
    }
    
    .hero-image {
        max-width: 80%;
        margin: 0 auto 2rem auto;
    }
    
    .hero-section h1,
    .hero-section .lead {
        text-align: center;
        padding: 0 15px;
    }
    
    .hero-section .btn-lg {
        margin: 0 auto;
        width: auto;
        min-width: 200px;
    }
}

@media (max-width: 576px) {
    .hero-section h1 {
        font-size: 2rem;
    }
    
    .hero-image {
        max-width: 90%;
    }
}

/* Eğitim kartı stilleri */
.training-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border: none;
}

.training-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

.training-card .card-img-top {
    height: 160px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(45deg, #f8f9fa, #e9ecef);
}

.training-card .list-unstyled li {
    font-size: 0.9rem;
}

.training-card .btn {
    transition: all 0.3s ease;
}

.training-card .btn:hover {
    transform: scale(1.05);
}

.training-card .card-title {
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 1rem;
    color: #2d3436;
}
</style>



<?php include 'includes/footer.php'; ?> 